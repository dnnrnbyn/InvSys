﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace InventoryManagement
{
    public partial class InventoryManagement : Form
    {

        DataTable inventory = new DataTable();

        public InventoryManagement()
        {
            InitializeComponent();
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            txtSKU.Text = "";
            txtName.Text = "";
            cbCategory.SelectedIndex = -1;
            txtPrice.Text = "";
            txtQuantity.Text = "";
            txtDescription.Text = "";
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            String sku = txtSKU.Text;
            String name = txtName.Text;
            String category = (string)cbCategory.SelectedItem;
            String price = txtPrice.Text;
            String quantity = txtQuantity.Text;
            String description = txtDescription.Text;

            inventory.Rows.Add(sku, name, category, price, quantity, description);

            btnReset_Click(sender, e);
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                inventory.Rows[inventoryGridView.CurrentCell.RowIndex].Delete();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex);
            }
        }

        private void inventoryGridView_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                txtSKU.Text = inventory.Rows[inventoryGridView.CurrentCell.RowIndex].ItemArray[0].ToString();
                txtName.Text = inventory.Rows[inventoryGridView.CurrentCell.RowIndex].ItemArray[1].ToString();
                String item = inventory.Rows[inventoryGridView.CurrentCell.RowIndex].ItemArray[2].ToString();
                cbCategory.SelectedIndex = cbCategory.Items.IndexOf(item);
                txtPrice.Text = inventory.Rows[inventoryGridView.CurrentCell.RowIndex].ItemArray[3].ToString();
                txtQuantity.Text = inventory.Rows[inventoryGridView.CurrentCell.RowIndex].ItemArray[4].ToString();
                txtDescription.Text = inventory.Rows[inventoryGridView.CurrentCell.RowIndex].ItemArray[5].ToString();
            }
            catch (Exception ex)
            {
                Console.WriteLine("There is an error: " + ex);
            }
        }

        private void InventoryManagement_Load(object sender, EventArgs e)
        {
            inventory.Columns.Add("SKU");
            inventory.Columns.Add("Name");
            inventory.Columns.Add("Category");
            inventory.Columns.Add("Price");
            inventory.Columns.Add("Quantity");
            inventory.Columns.Add("Description");

            inventoryGridView.DataSource = inventory;
        }
    }
}
